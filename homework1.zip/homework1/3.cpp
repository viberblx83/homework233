#include <iostream>
using namespace std;

int main() {
    int arr[10];
    double sum = 0;
    cout << "-20 ve 20 arasinda random rqmlər daxil edin:\n";
    for (int i = 0; i < 10; ++i) {
        cin >> arr[i];
        if (arr[i] > 0) {
            sum += arr[i];
        }
    }

    double average = sum / 10;
    cout << "musbet ededlerin ededi ortasi: " << average << endl;

    return 0;
}
