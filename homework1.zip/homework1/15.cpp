#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

bool isPrime(int n) {
    if (n <= 1) return false;
    for (int i = 2; i * i <= n; ++i) {
        if (n % i == 0) return false;
    }
    return true;
}

int main() {
    int arr[20];
    srand(time(0));

    for (int i = 0; i < 20; ++i) {
        arr[i] = rand() % 199 + 2; 
    }

    cout << "sadereqemler: ";
    for (int i = 0; i < 20; ++i) {
        if (isPrime(arr[i])) {
            cout << arr[i] << " ";
        }
    }
    cout << endl;

    return 0;
}
