#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cctype>
using namespace std;

int main() {
    char arr[10];
    srand(time(0)); //Tesadifu reqemler generatoruna sistem vaxitina eseslanan bir baslangic deyer teyin edir


    for (int i = 0; i < 10; ++i) {
        arr[i] = rand() % 256; 
    }

    int letter_count = 0, digit_count = 0, punct_count = 0;

    for (int i = 0; i < 10; ++i) {
        if (isalpha(arr[i])) {
            ++letter_count;
        } else if (isdigit(arr[i])) {
            ++digit_count;
        } else if (ispunct(arr[i])) {
            ++punct_count;
        }
    }

    cout << "herf sayi: " << letter_count << endl;
    cout << "reqemlersayi: " << digit_count << endl;
    cout << " punk simvollar sayi " << punct_count << endl;

    return 0;
}
