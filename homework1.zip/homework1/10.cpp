#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[10];
    srand(time(0));

    for (int i = 0; i < 10; ++i) {
        arr[i] = rand() % 41 - 10; 
    }

    int sum = 0;
    bool found_negative = false;

    for (int i = 0; i < 10; ++i) {
        if (found_negative) {
            sum += arr[i];
        }
        if (arr[i] < 0) {
            found_negative = true;
        }
    }

    cout << "Birinci menfi ededden sonra gelen reqemlerin cemi: " << sum << endl;

    return 0;
}
