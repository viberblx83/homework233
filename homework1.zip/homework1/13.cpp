#include <iostream>
using namespace std;

int main() {
    double arr[10] = {12, 12.5, 10.1, 1.0, 2.0, 7.5, 3.0, 4.6, 5.0, 6.0};
    int count = 0;

    for (int i = 0; i < 10; ++i) {
        if (arr[i] == static_cast<int>(arr[i])) {
            ++count;
        }
    }

    cout << "kesr olmayann ededdlerinsayi: " << count << endl;

    return 0;
}
