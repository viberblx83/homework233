#include <iostream>
using namespace std;

int main() {
    int arr[20];
    int menfi = 0, bilmirem = 0, sifir = 0;
    cout << "-5  5 arasinda random eded daxil et:\n";
    for (int i = 0; i < 20; ++i) {
        cin >> arr[i];
        if (arr[i] < 0) {
            menfi++;
        } else if (arr[i] > 0) {
            bilmirem++;
        } else {
            sifir++;
        }
    }

    cout << "menfi sayi: " << menfi << endl;
    cout << "musbetlerin sayi: " << bilmirem<< endl;
    cout << "sifirlarin sayı: " << sifir << endl;

    return 0;
}
