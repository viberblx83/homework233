#include <iostream>
using namespace std;

int main() {
    int C[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    int A[5], B[5];

    for (int i = 0; i < 5; ++i) {
        A[i] = C[2 * i];
        B[i] = C[2 * i + 1];
    }

    cout << "A massivi: ";
    for (int i = 0; i < 5; ++i) {
        cout << A[i] << " ";
    }
    cout << endl;

    cout << "B massivi: ";
    for (int i = 0; i < 5; ++i) {
        cout << B[i] << " ";
    }
    cout << endl;

    return 0;
}
