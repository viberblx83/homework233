#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[50];
    srand(time(0));

    for (int i = 0; i < 50; ++i) {
        arr[i] = rand() % 100 + 1;
    }

    int user_number;
    cout << "1-100 arasinda reqem daxil et: ";
    cin >> user_number;

    int count = 0;


    for (int i = 0; i < 50; ++i) {
        if (arr[i] == user_number) {
            ++count;
        }
    }

    cout << "Massivde " << user_number << "reqeminden " << count << " dene var." << endl;

    return 0;
}
