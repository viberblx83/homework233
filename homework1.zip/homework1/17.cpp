#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[10];
    srand(time(0));

    for (int i = 0; i < 10; ++i) {
        arr[i] = rand() % 100; 
    }

    for (int i = 0; i < 9; i += 2) {
        swap(arr[i], arr[i + 1]);
    }

    cout << " massiv: ";
    for (int i = 0; i < 10; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
