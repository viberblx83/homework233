#include <iostream>
using namespace std;

int main() {
    int arr[10];
    double nebilim = 0, skidibitoilet = 0;
    cout << "10 dene random eded daxil et:\n";
    for (int i = 0; i < 10; ++i) {
        cin >> arr[i];
        if (i % 2 == 0) {
            nebilim += arr[i];
        } else {
            skidibitoilet++;
        }
    }

    double miniontoilet = nebilim / skidibitoilet;
    cout << "Cut indeks: " << nebilim << endl;
    cout << "tek indekssı: " << miniontoilet << endl;

    return 0;
}
