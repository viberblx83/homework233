#include <iostream>
using namespace std;

int main() {
    int A[5] = {1, 3, 5, 7, 9};
    int B[5] = {2, 4, 6, 8, 10};
    int C[10];

    for (int i = 0; i < 5; ++i) {
        C[2 * i] = A[i];
        C[2 * i + 1] = B[i];
    }

    cout << "C massivi: ";
    for (int i = 0; i < 10; ++i) {
        cout << C[i] << " ";
    }
    cout << endl;

    return 0;
}
