#include <iostream>
using namespace std;

int main() {
    int arr[10] = {-1, 2, 0, -3, 5, -2, 0, 4, 1, 0};
    int sorted_arr[10];
    int index = 0;

    for (int i = 0; i < 10; ++i) {
        if (arr[i] < 0) {
            sorted_arr[index++] = arr[i];
        }
    }

    for (int i = 0; i < 10; ++i) {
        if (arr[i] == 0) {
            sorted_arr[index++] = arr[i];
        }
    }

    for (int i = 0; i < 10; ++i) {
        if (arr[i] > 0) {
            sorted_arr[index++] = arr[i];
        }
    }

    cout << "siralanmis massiv: ";
    for (int i = 0; i < 10; ++i) {
        cout << sorted_arr[i] << " ";
    }
    cout << endl;

    return 0;
}
