#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[20];
    srand(time(0));

    for (int i = 0; i < 20; ++i) {
        arr[i] = rand() % 200 + 1; 
    }

    int one_digit_count = 0, two_digit_count = 0, three_digit_count = 0;

    for (int i = 0; i < 20; ++i) {
        if (arr[i] < 10) {
            ++one_digit_count;
        } else if (arr[i] < 100) {
            ++two_digit_count;
        } else {
            ++three_digit_count;
        }
    }

    double one_digit_percent = (one_digit_count / 20.0) * 100;
    double two_digit_percent = (two_digit_count / 20.0) * 100;
    double three_digit_percent = (three_digit_count / 20.0) * 100;

    cout << "1 reqemli ededlerin sayi faizi: " << one_digit_percent << "%" << endl;
    cout << "2 reqemli ededlerin faizi: " << two_digit_percent << "%" << endl;
    cout << "3 reqemli ededlerin faizi: " << three_digit_percent << "%" << endl;

    return 0;
}
