#include <iostream>
using namespace std;

int main() {
    int arr[5];
    cout << "5dana reqem yaz:\n";
    for (int i = 0; i < 5; ++i) {
        cin >> arr[i];
    }

    cout << "tersi:\n";
    for (int i = 4; i >= 0; --i) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
