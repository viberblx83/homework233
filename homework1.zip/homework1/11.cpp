#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[10];
    srand(time(0));

    for (int i = 0; i < 10; ++i) {
        arr[i] = rand() % 51 - 30; 
    }

    int sum = 0;
    bool found_positive = false;

    for (int i = 0; i < 10; ++i) {
        if (found_positive) {
            sum += arr[i];
        }
        if (arr[i] > 0) {
            found_positive = true;
        }
    }

    cout << "Birinci musbet ededden sonra gelen reqmelerin cemi: " << sum << endl;

    return 0;
}
