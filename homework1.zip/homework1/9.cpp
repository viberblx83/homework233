#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[10];
    srand(time(0));

    for (int i = 0; i < 10; ++i) {
        arr[i] = rand() % 100 + 1; 
    }

    int count = 0;

    for (int i = 0; i < 10; ++i) {
        if (arr[i] % 3 == 0 && arr[i] % 5 != 0) {
            ++count;
        }
    }

    cout << "3bolunum 5 bolunmeyenlerin sayi: " << count << endl;

    return 0;
}
