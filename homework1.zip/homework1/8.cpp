#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[10];
    srand(time(0));

    for (int i = 0; i < 10; ++i) {
        arr[i] = rand() % 100 + 1; 
    }

    int count3 = 0, count5 = 0, count7 = 0;

    for (int i = 0; i < 10; ++i) {
        if (arr[i] % 3 == 0) ++count3;
        if (arr[i] % 5 == 0) ++count5;
        if (arr[i] % 7 == 0) ++count7;
    }

    cout << "3bolulenler say  " << count3 << endl;
    cout << "5 bolunenlersaysi:  " << count5 << endl;
    cout << "7 bolulenen sayisi: " << count7 << endl;

    return 0;
}
