#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[20];
    srand(time(0));

    for (int i = 0; i < 20; ++i) {
        arr[i] = rand() % 100;
    }

    int max_val = arr[0], min_val = arr[0];
    int max_index = 0, min_index = 0;

    for (int i = 1; i < 20; ++i) {
        if (arr[i] > max_val) {
            max_val = arr[i];
            max_index = i;
        }
        if (arr[i] < min_val) {
            min_val = arr[i];
            min_index = i;
        }
    }

    cout << "min elemt: " << max_val << " (indeks: " << max_index << ")" << endl;
    cout << "max elemt: " << min_val << " (index: " << min_index << ")" << endl;

    return 0;
}
