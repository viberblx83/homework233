#include <iostream>
using namespace std;

int main() {
    int arr[20];
    cout << "20dene reqem yaz:\n";
    for (int i = 0; i < 20; ++i) {
        cin >> arr[i];
    }

    cout << "cut indesli eded::\n";
    for (int i = 0; i < 20; i += 2) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
