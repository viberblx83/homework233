#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int arr[10];
    srand(time(0));

 
    for (int i = 0; i < 10; ++i) {
        arr[i] = rand() % 100; 
    }

    for (int i = 0; i < 5; ++i) {
        swap(arr[i], arr[9 - i]);
    }

    cout << "tersine cevirlimsis massiv: ";
    for (int i = 0; i < 10; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
